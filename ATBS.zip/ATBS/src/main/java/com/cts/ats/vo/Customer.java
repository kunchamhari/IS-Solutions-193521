package com.cts.ats.vo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "usr_dtls")
public class Customer {
	
	
	@Id
	 @GeneratedValue(strategy = GenerationType.AUTO)
	 @Column(name = "userId")
	 private int userId;
	
	 @Column(name = "USR_PWD")
	private String password;
	@Column(name = "USR_EMAIL", nullable = false, unique = true)
	private String emailId;
	
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	
}
