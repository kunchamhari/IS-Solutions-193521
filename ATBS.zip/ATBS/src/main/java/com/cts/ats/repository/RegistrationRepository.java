package com.cts.ats.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cts.ats.vo.Customer;

@Repository("usr_dtls")
public interface RegistrationRepository extends CrudRepository<Customer, Long> {

	Customer findByEmailId(String email);
}
