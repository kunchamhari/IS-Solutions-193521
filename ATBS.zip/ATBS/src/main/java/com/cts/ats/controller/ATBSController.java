package com.cts.ats.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.ats.service.UserRegistrationService;
import com.cts.ats.vo.Customer;
import com.cts.ats.vo.CustomerBean;
import com.cts.ats.vo.Response;
import com.cts.ats.vo.Ticket;

@RestController
public class ATBSController {
	
	
	private UserRegistrationService userService;
	
	
	@Autowired
	public ATBSController(UserRegistrationService userService) {
		this.userService = userService;
	}
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home() {
		return "atsIndex";
	}
	
	@RequestMapping(value = "/register", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody
	public Response registerUser(@RequestBody @Valid CustomerBean customerBean,	BindingResult bindingResult) {
		Response response = new Response();
		try {
			System.out.println("aaa"+customerBean.getEmailId());
			System.out.println("bb"+customerBean.getPassword());
			System.out.println("bb"+customerBean.getConfirmPassword());
			if(bindingResult.hasErrors()){
				List<ObjectError> errorsList = bindingResult.getAllErrors();
				List<String> errorMessage = new ArrayList<String>();
				for(ObjectError objectError: errorsList){
					String codes[] =objectError.getCodes();
					String field = codes[0].split("\\.")[2];
					errorMessage.add(field+" "+objectError.getDefaultMessage());
				}
				response.setSuccess(false);
				response.setData(errorMessage.toArray());
			
			} else {
				Customer customer = new Customer();
				customer.setEmailId(customerBean.getEmailId());
				customer.setPassword(customerBean.getPassword());
				userService.saveUser(customer);
				response.setSuccess(true);
				response.setData("User Registration Successful. ");
			}
		} catch (Exception ex) {
			response.setSuccess(false);
			response.setData("Registration Failed. ");
		}
		return response;
	}
	
	
	@RequestMapping(value = "/login", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody
	public Response login(@RequestBody CustomerBean userBean) {
		Response response = new Response();
		try {
			userBean.setEmailId(userBean.getUsername());
			Customer customer = userService.authenticateUser(userBean);
			if (customer != null) {
				response.setSuccess(true);
				response.setData(customer);
			} else {
				response.setSuccess(false);
				response.setData("Invalid Credentials");
			}

		} catch (Exception ex) {
			response.setSuccess(false);
			response.setData("Invalid Credentials");
		}
		return response;
	}
	
	
}
