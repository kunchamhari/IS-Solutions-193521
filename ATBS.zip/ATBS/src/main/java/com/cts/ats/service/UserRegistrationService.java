package com.cts.ats.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.ats.repository.RegistrationRepository;
import com.cts.ats.vo.Customer;
import com.cts.ats.vo.CustomerBean;

@Service("userService")
public class UserRegistrationService {

	
	private RegistrationRepository userRepository;
	
	@Autowired
	public UserRegistrationService(RegistrationRepository userRepository) {
		this.userRepository = userRepository;
	}
	
	 public void saveUser(Customer user) {
		  userRepository.save(user);
		}
	 public  Customer authenticateUser(CustomerBean user) {
		 
		 Customer customer = userRepository.findByEmailId(user.getEmailId());
		 if(customer.getPassword() != null && customer.getPassword().equals(user.getPassword()))
		 {
			 return customer;
		 }else {
			 return null;
		 }
	 }
}
