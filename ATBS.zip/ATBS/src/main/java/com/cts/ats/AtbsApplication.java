package com.cts.ats;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtbsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtbsApplication.class, args);
		System.out.println("Testing");
	}
}
