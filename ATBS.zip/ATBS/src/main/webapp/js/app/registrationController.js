(function(){
	var app = angular.module("ATSapp");
	app.controller("RegistrationController", ['$scope','$http','$state','$window',function($scope,$http,$state) {
		
		$scope.customer ={};
		
		$scope.errorsList = [];
		$scope.successmsg = "";
		$scope.resetForm = function(){
			$scope.customer ={};
		};
		
		$scope.registration =function(){
		  $scope.errorsList = [];
	      $http.post('/ats/register', $scope.customer).then(function(response){
	    	  if(response.data.success){
	    		  $scope.successmsg = response.data.data;
	    		  $scope.resetForm();
	    	  }else{
	    		  $scope.errorsList = response.data.data;
	    	  }
	      }); 
	   };
	   $scope.cancel =function(){
		   $state.go('login');
	   };
	}]);
})();

