(function(){
	var app = angular.module("ATSapp");
	app.controller("LoginController", ['$scope','$http','appstore', '$state', '$rootScope',
	  function($scope, $http, appstore, $state, $rootScope) {
		$scope.user ={
			  username:'',
			  password:''
		};
		$rootScope.username = '';
		$scope.login =function(){
	      $http.post('/ats/login', $scope.user).then(function(response){
	    	  if(response.data.success){
	    		  appstore.storeData('userDetails', response.data.data);
	    		  $rootScope.username = response.data.data.emailId;
	    		  $state.go('managebookings');
	    	  }else{
	    		  $scope.errormsg = response.data.data;
	    	  }
	      }); 
	  };
	}]);
})();
